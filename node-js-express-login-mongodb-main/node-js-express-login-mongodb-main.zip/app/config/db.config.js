module.exports = {
  HOST: "localhost",
  url: "mongodb://localhost:27017/testdb",
  PORT: 27017,
  DB: "testdb"
};